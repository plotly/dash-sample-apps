from plotly.graph_objs import Funnel
