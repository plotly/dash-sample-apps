# # ### Accept None ###
# def test_accept_none(validator: NumberValidator):
#     assert validator.validate_coerce(None) is None


# Test numpy arrays readonly
