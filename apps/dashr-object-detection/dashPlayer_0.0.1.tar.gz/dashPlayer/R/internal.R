.dashPlayer_js_metadata <- function() {
deps_metadata <- list(`dash_player` = structure(list(name = "dash_player",
version = "0.0.1", src = list(href = NULL,
file = "deps"), meta = NULL,
script = "dash_player.min.js",
stylesheet = NULL, head = NULL, attachment = NULL, package = "dashPlayer",
all_files = FALSE), class = "html_dependency"))
return(deps_metadata)
}